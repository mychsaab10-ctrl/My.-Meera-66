package com.meera.ai.eyes

import android.Manifest
import android.app.Application
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.os.BatteryManager
import android.os.Build
import android.os.PowerManager
import android.os.SystemClock
import android.util.Base64
import androidx.core.content.ContextCompat
import com.meera.ai.Meera
import com.meera.ai.ToolOut
import com.meera.ai.ai.Attach
import com.meera.ai.ai.ChatMsg
import com.meera.ai.ai.GeminiException
import com.meera.ai.ai.Mood
import com.meera.ai.ai.Persona
import com.meera.ai.voice.CallState
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull
import org.json.JSONObject
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/** The answer card on the Eyes screen. [busy] = Meera is still thinking. */
data class EyesCard(val question: String, val answer: String, val busy: Boolean = false)

/**
 * "Meera Eyes": the camera feature (v2.1).
 *
 * RULES (privacy):
 *  - The camera opens ONLY through [runCommand], which is reached only from a command the user typed/said
 *    ("open your eyes", "aankhein kholo", "camera on") that [EyesCommands] matched locally.
 *  - It closes on the close command, the Close button, Back, when the app goes to the background,
 *    after the auto-close time, or when the phone is too hot / the battery is nearly empty.
 *  - Frames exist only in memory and go only to Gemini while Eyes are ON. Nothing is saved or recorded.
 *  - A person is only ever labelled HUMAN: no name, no face recognition, no age, no emotions.
 *
 * Thread rules: all state changes happen on the main thread (Meera.scope). The camera analysis thread only calls
 * [wantsFrame] and [onFrame].
 */
class EyesController(private val app: Application, private val scope: CoroutineScope) {

    val isOpen = MutableStateFlow(false)
    val lensFront = MutableStateFlow(false)
    val boxes = MutableStateFlow<List<HudBox>>(emptyList())
    val summary = MutableStateFlow("")
    val card = MutableStateFlow<EyesCard?>(null)
    val qaBusy = MutableStateFlow(false)
    /** width / height of the upright analysis frame (3/4 for a 4:3 portrait picture). Used to place HUD boxes. */
    val frameAspect = MutableStateFlow(3f / 4f)

    val camera = EyesCamera(app, this)

    // ----- per-session values (copied from Settings when the eyes open) -----
    @Volatile private var session = 0
    @Volatile private var scanMs = 2500L
    @Volatile private var hudOn = true
    @Volatile private var continuous = false
    @Volatile private var expiryMs = 4000L

    @Volatile private var hudBusy = false
    @Volatile private var lastHudAt = 0L
    @Volatile private var lastLiveAt = 0L
    @Volatile private var snapWaiter: CompletableDeferred<ByteArray>? = null
    @Volatile private var lastJpeg: ByteArray? = null

    private var pendingOpen = false
    private var autoJob: Job? = null
    private var tickJob: Job? = null
    private var hudJob: Job? = null
    private var qaJob: Job? = null
    private val qa = ArrayList<ChatMsg>()
    private var nextId = 1L
    private var spoke = false
    private var lastSpokenSummary = ""
    private var lastSpokenAt = 0L

    // ───────────── permission + commands ─────────────

    fun hasPermission(): Boolean =
        ContextCompat.checkSelfPermission(app, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED

    /**
     * Executes an explicit user command and returns the sentence Meera says/shows.
     * The caller must have matched the command with [EyesCommands] from the user's own words.
     */
    fun runCommand(cmd: EyesCmd): String = when (cmd) {
        EyesCmd.OPEN -> requestOpen()
        EyesCmd.CLOSE -> {
            pendingOpen = false
            if (!isOpen.value) "My eyes are already closed."
            else { close(); "Okay, I closed my eyes." }
        }
    }

    private fun requestOpen(): String {
        if (isOpen.value) return "My eyes are already open 👀 Ask me something, for example \"what is this?\""
        if (!hasPermission()) {
            val ask = Meera.requestCamera
            if (ask == null) return "Camera permission is missing. Allow Camera in the Permissions screen."
            pendingOpen = true
            ask()
            return "I need camera permission. Tap Allow and my eyes will open."
        }
        open()
        return "Eyes open 👀 I can see now. Ask me something, for example \"what is this?\""
    }

    /** Result of the Android permission dialog (called by MainActivity). */
    fun onPermissionResult(granted: Boolean) {
        val wanted = pendingOpen
        pendingOpen = false
        if (granted) {
            if (wanted) open() else Meera.toast("Camera allowed. Now say: \"open your eyes\".")
        } else {
            Meera.toast("Camera not allowed. Allow it in the Permissions screen.")
        }
    }

    /** What the Live model is told right after the eyes opened (so it knows how it will see). */
    fun liveHint(): String =
        if (Meera.settings.liveVideo == "stream")
            "Camera frames now arrive about once per second; answer questions from what you see (frames can be about a second old)."
        else
            "You do NOT get live video. For every question about what is in view, call look_camera with the question and tell the user the result in your own words."

    // ───────────── open / close ─────────────

    private fun open() {
        if (isOpen.value) return
        session++
        val st = Meera.settings
        scanMs = (st.eyesScanSec.coerceIn(2f, 5f) * 1000f).toLong()
        hudOn = st.eyesHud
        continuous = st.eyesContinuous
        // boxes disappear 4 s after they were last seen; with a slow scan interval keep them until the next scan
        expiryMs = max(4000L, scanMs + 1500L)
        qa.clear()
        boxes.value = emptyList()
        summary.value = ""
        card.value = null
        qaBusy.value = false
        hudBusy = false
        lastHudAt = 0L
        lastLiveAt = 0L
        lastJpeg = null
        lastSpokenSummary = ""
        lastSpokenAt = SystemClock.elapsedRealtime()
        lensFront.value = st.eyesFront
        isOpen.value = true

        val mins = st.eyesAutoCloseMin.coerceIn(1, 30)
        autoJob?.cancel()
        autoJob = scope.launch {
            delay(mins * 60_000L)
            close("Eyes closed automatically after $mins minute(s).")
        }
        tickJob?.cancel()
        tickJob = scope.launch {
            var n = 0
            while (isActive) {
                delay(500)
                pruneBoxes()
                if (++n % 20 == 0) safetyCheck()
            }
        }
    }

    /** Closes the camera. [notice] is shown as a toast for automatic closes (timer, heat, battery, error). */
    fun close(notice: String? = null) {
        if (!isOpen.value) return // (a pending "open after permission" must survive, e.g. while the permission dialog is on screen)
        pendingOpen = false
        session++ // late answers from Gemini are thrown away
        isOpen.value = false
        autoJob?.cancel(); autoJob = null
        tickJob?.cancel(); tickJob = null
        hudJob?.cancel(); hudJob = null
        qaJob?.cancel(); qaJob = null
        hudBusy = false
        snapWaiter?.cancel(); snapWaiter = null
        lastJpeg = null
        boxes.value = emptyList()
        summary.value = ""
        card.value = null
        qaBusy.value = false
        qa.clear()
        if (spoke) { Meera.tts.stop(); spoke = false }
        if (notice != null) Meera.toast(notice)
    }

    fun onCameraError(msg: String) {
        close(msg)
    }

    private fun safetyCheck() {
        if (!isOpen.value) return
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                val pm = app.getSystemService(android.content.Context.POWER_SERVICE) as PowerManager
                if (pm.currentThermalStatus >= PowerManager.THERMAL_STATUS_SEVERE) {
                    close("Eyes closed: the phone is too hot.")
                    return
                }
            }
            val b: Intent? = app.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            if (b != null) {
                val level = b.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
                val scale = b.getIntExtra(BatteryManager.EXTRA_SCALE, -1)
                val status = b.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
                val charging = status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL
                if (level >= 0 && scale > 0 && !charging && level * 100 / scale <= 8) {
                    close("Eyes closed: the battery is low.")
                }
            }
        } catch (e: Exception) { /* safety check is best-effort */ }
    }

    // ───────────── frames (called from the camera analysis thread) ─────────────

    private fun scanNeeded() = hudOn || continuous
    private fun hudDue(now: Long) = scanNeeded() && !hudBusy && now - lastHudAt >= scanMs
    private fun liveDue(now: Long) = now - lastLiveAt >= 1000L && Meera.call.canSendVideo()

    /** Should this camera frame be converted to a JPEG? (false for almost every frame) */
    fun wantsFrame(now: Long): Boolean {
        if (!isOpen.value) return false
        return snapWaiter != null || hudDue(now) || liveDue(now)
    }

    fun onFrame(jpeg: ByteArray, w: Int, h: Int, now: Long) {
        if (!isOpen.value || h <= 0) return
        lastJpeg = jpeg
        val asp = w.toFloat() / h.toFloat()
        if (abs(asp - frameAspect.value) > 0.01f) frameAspect.value = asp
        val waiter = snapWaiter
        if (waiter != null) { snapWaiter = null; waiter.complete(jpeg) }
        if (liveDue(now)) { lastLiveAt = now; Meera.call.sendVideoFrame(jpeg) } // Live call: about 1 frame / second
        if (hudDue(now)) {
            lastHudAt = now
            hudBusy = true // a new frame is skipped while this request is running
            val s = session
            hudJob = scope.launch { scanHud(jpeg, s) }
        }
    }

    /** A fresh camera frame for a question (waits up to 3 s, then falls back to the last one). */
    suspend fun snapshot(): ByteArray? {
        if (!isOpen.value) return null
        val d = CompletableDeferred<ByteArray>()
        snapWaiter = d
        val r = withTimeoutOrNull(3000L) { d.await() }
        if (r == null && snapWaiter === d) snapWaiter = null
        return r ?: lastJpeg
    }

    fun attach(jpeg: ByteArray) = Attach("image/jpeg", Base64.encodeToString(jpeg, Base64.NO_WRAP))

    // ───────────── HUD scan ─────────────

    private suspend fun scanHud(jpeg: ByteArray, s: Int) {
        try {
            val r = Meera.gemini.generate(
                Meera.settings.model, null,
                listOf(ChatMsg("user", hudPrompt())),
                0.3, attachments = listOf(attach(jpeg)), jsonMode = true, fast = true
            )
            if (s != session || !isOpen.value) return
            val res = HudParser.parse(r.text) ?: return
            mergeBoxes(res.objects, SystemClock.elapsedRealtime())
            if (res.summary.isNotBlank()) summary.value = res.summary
            maybeDescribe(res.summary)
        } catch (e: GeminiException) {
            // a failed scan is not fatal: the HUD just keeps the last boxes until they expire
        } finally {
            if (s == session) hudBusy = false
        }
    }

    private fun hudPrompt(): String =
        "You are the vision system of an augmented-reality HUD. Look at the image and return ONLY a JSON object, no markdown:\n" +
            "{\"summary\":\"<one short sentence about the scene, max 14 words, in ${Meera.settings.language}>\"," +
            "\"objects\":[{\"label\":\"<1-2 word English noun, e.g. DOG, TREE, PHONE, CUP>\",\"category\":\"<human|animal|plant|vehicle|food|object|other>\"," +
            "\"box_2d\":[ymin,xmin,ymax,xmax]}]}\n" +
            "Rules: at most 8 objects, the clearest and most important ones. box_2d are integers from 0 to 1000, relative to the whole image. " +
            "For every person use label \"HUMAN\" and category \"human\" ONLY: never a name, never say who they are, no age, no gender, no emotion. " +
            "The summary must not identify any person either. If nothing is visible return an empty objects list."

    private fun iou(b: HudBox, d: Detection): Float {
        val il = max(b.left, d.left); val itop = max(b.top, d.top)
        val ir = min(b.right, d.right); val ib = min(b.bottom, d.bottom)
        val iw = ir - il; val ih = ib - itop
        if (iw <= 0f || ih <= 0f) return 0f
        val inter = iw * ih
        val ua = (b.right - b.left) * (b.bottom - b.top) + (d.right - d.left) * (d.bottom - d.top) - inter
        return if (ua <= 0f) 0f else inter / ua
    }

    /** Matches new detections to boxes already on screen (same id => the UI animates the move smoothly). */
    private fun mergeBoxes(dets: List<Detection>, now: Long) {
        val cur = boxes.value
        val used = HashSet<Long>()
        val out = ArrayList<HudBox>()
        for (d in dets) {
            var best: HudBox? = null
            var bestScore = 0f
            for (b in cur) {
                if (b.id in used || b.category != d.category) continue
                val i = iou(b, d)
                val same = b.label == d.label
                val dx = (b.left + b.right) / 2f - (d.left + d.right) / 2f
                val dy = (b.top + b.bottom) / 2f - (d.top + d.bottom) / 2f
                val near = (dx * dx + dy * dy) < 0.0625f // centers closer than 0.25 of the frame
                if (i > 0.2f || (same && near)) {
                    val score = i + (if (same) 0.2f else 0f)
                    if (score > bestScore || best == null) { best = b; bestScore = score }
                }
            }
            if (best != null) {
                used.add(best.id)
                out.add(best.copy(label = d.label, left = d.left, top = d.top, right = d.right, bottom = d.bottom, seenAt = now, stale = false))
            } else {
                out.add(HudBox(nextId++, d.label, d.category, d.left, d.top, d.right, d.bottom, now))
            }
        }
        for (b in cur) if (b.id !in used && now - b.seenAt < expiryMs) out.add(b) // keep until they expire
        boxes.value = out.take(12)
    }

    /** Removes boxes older than the expiry time and fades the ones that are about to go. */
    private fun pruneBoxes() {
        val cur = boxes.value
        if (cur.isEmpty()) return
        val now = SystemClock.elapsedRealtime()
        val next = cur.filter { now - it.seenAt < expiryMs }.map {
            val st = now - it.seenAt >= expiryMs - 1000L
            if (st == it.stale) it else it.copy(stale = st)
        }
        if (next != cur) boxes.value = next
    }

    /** Optional "continuous description" (Settings, default OFF): Meera reads out the scene summary now and then. */
    private fun maybeDescribe(text: String) {
        if (!continuous || text.isBlank() || qaBusy.value) return
        val now = SystemClock.elapsedRealtime()
        if (text == lastSpokenSummary || now - lastSpokenAt < 10_000L) return
        lastSpokenSummary = text
        lastSpokenAt = now
        card.value = EyesCard("👁 Scene", text)
        speak(text)
    }

    // ───────────── questions ─────────────

    /** A question typed/dictated on the Eyes screen. Commands (e.g. "close your eyes") are handled here too. */
    fun ask(text: String) {
        val t = text.trim()
        if (t.isEmpty() || !isOpen.value) return
        Meera.lastUserText = t
        EyesCommands.match(t)?.let { cmd ->
            val reply = runCommand(cmd)
            if (isOpen.value) card.value = EyesCard(t, reply)
            return
        }
        Meera.interceptAnswer(t)?.let { card.value = EyesCard(t, it); speak(it); return }
        if (qaBusy.value) return
        qaJob?.cancel()
        qaJob = scope.launch { answer(t) }
    }

    private suspend fun answer(q: String) {
        val s = session
        qaBusy.value = true
        card.value = EyesCard(q, "", true)
        try {
            val jpeg = snapshot()
            if (s != session) return
            if (jpeg == null) {
                card.value = EyesCard(q, "⚠ I could not get a camera frame. Wait a moment and ask again.")
                return
            }
            val st = Meera.settings
            val history = qa.takeLast(10) + ChatMsg("user", q) // earlier questions/answers = the context for follow-ups
            val r = Meera.gemini.generate(st.model, Persona.system("eyes"), history, 0.5, attachments = listOf(attach(jpeg)))
            if (s != session) return
            val text = Mood.strip(r.text).ifBlank { "I could not make out the picture. Please bring it a little closer." }
            qa.add(ChatMsg("user", q)); qa.add(ChatMsg("model", text))
            card.value = EyesCard(q, text)
            speak(text)
        } catch (e: GeminiException) {
            if (s == session) card.value = EyesCard(q, "⚠ ${e.message ?: "Error"}")
        } finally {
            if (s == session) qaBusy.value = false
        }
    }

    /** Used by the fallback voice call: it asks Gemini itself (with the frame) and speaks itself; we only show the card. */
    fun noteCallAnswer(question: String, answer: String) {
        if (!isOpen.value) return
        card.value = EyesCard(question, answer)
        qa.add(ChatMsg("user", question)); qa.add(ChatMsg("model", answer))
        while (qa.size > 20) qa.removeAt(0)
    }

    /** Tool for the Live call in "snapshot" mode (and a state check in "stream" mode): one frame, answered by the chat model. */
    suspend fun lookTool(args: JSONObject): ToolOut {
        if (!isOpen.value) {
            return ToolOut("EYES_CLOSED: the camera is OFF, you cannot see anything. Tell the user honestly. They can say \"open your eyes\" to open your eyes.")
        }
        val q = args.optString("question").trim().ifBlank { "What is in front of the camera? Describe it." }
        val jpeg = snapshot() ?: return ToolOut("No camera frame available right now. Tell the user and ask them to try again in a moment.")
        return try {
            val r = Meera.gemini.generate(
                Meera.settings.model, Persona.system("eyes"), listOf(ChatMsg("user", q)), 0.4, attachments = listOf(attach(jpeg))
            )
            val t = Mood.strip(r.text).ifBlank { "Nothing clear is visible." }
            if (isOpen.value) card.value = EyesCard(q, t)
            ToolOut("CAMERA_RESULT (tell this to the user in your own words and in their language; do not mention coordinates): $t")
        } catch (e: GeminiException) {
            ToolOut("Camera look failed: ${e.message ?: "error"}. Tell the user.")
        }
    }

    fun stopSpeaking() {
        if (spoke) Meera.tts.stop()
    }

    private fun speak(text: String) {
        // during a call the call itself talks; a second voice on top would be a mess
        val cs = Meera.call.state.value
        if (cs != CallState.Idle && cs != CallState.Error) return
        spoke = true
        Meera.tts.speak(text)
    }
}
