package com.meera.ai.ui

import androidx.annotation.DrawableRes
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.meera.ai.R

/** Content card (kept under its old name so every screen gets the new glass look). */
@Composable
fun GlowCard(modifier: Modifier = Modifier, onClick: (() -> Unit)? = null, content: @Composable ColumnScope.() -> Unit) {
    GlassPanel(modifier, onClick, content = content)
}

@Composable
fun SectionTitle(text: String) {
    Text(text, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold, fontSize = 15.sp, modifier = Modifier.padding(top = 14.dp, bottom = 6.dp))
}

@Composable
fun Chip(text: String, ok: Boolean? = null) {
    val c = when (ok) { true -> Color(0xFF34D399); false -> Pink; null -> MaterialTheme.colorScheme.onSurfaceVariant }
    Row(
        Modifier.clip(RoundedCornerShape(50)).background(c.copy(alpha = 0.16f)).border(1.dp, c.copy(alpha = 0.45f), RoundedCornerShape(50))
            .padding(horizontal = 10.dp, vertical = 4.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) { Text(text, color = c, fontSize = 12.sp) }
}

/** Still face picture for each mood (cut from the first frame of the matching video). Used for SMALL avatars only. */
@DrawableRes
private fun faceFor(mood: String, talking: Boolean): Int = when {
    talking -> R.drawable.face_talk
    mood == "sad" -> R.drawable.face_sad
    mood == "excited" -> R.drawable.face_excited
    mood == "thinking" -> R.drawable.face_thinking
    mood == "happy" || mood == "loving" -> R.drawable.face_happy
    else -> R.drawable.face_normal
}

/**
 * Small round avatar (chat header, eyes screen, About). It is just a light still picture, so lists and chat stay smooth.
 * The BIG avatar (Home / Call) is the full-screen video: see [AvatarStage].
 */
@Composable
fun Avatar(size: Dp, mood: String = "normal", talking: Boolean = false, modifier: Modifier = Modifier) {
    Box(
        modifier.size(size).clip(CircleShape)
            .border(1.5.dp, Brush.linearGradient(listOf(Color.White.copy(alpha = 0.85f), Cyan.copy(alpha = 0.3f), Color.White.copy(alpha = 0.5f))), CircleShape)
    ) {
        Crossfade(targetState = faceFor(mood, talking), animationSpec = tween(350), label = "face") { r ->
            Image(painterResource(r), contentDescription = "Meera", modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        }
    }
}
