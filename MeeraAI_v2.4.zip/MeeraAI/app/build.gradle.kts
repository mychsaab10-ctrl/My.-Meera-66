plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.meera.ai"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.meera.ai"
        minSdk = 26
        targetSdk = 34
        versionCode = 6
        versionName = "2.4.0"
    }

    // One FIXED signing key (app/debug.keystore, committed to the repo). Every build - Termux, GitHub Actions,
    // anywhere - is signed with the same key, so a new APK installs directly over the old Meera (no uninstall).
    // This is the standard public "android" debug key: fine for personal sideloading, NOT for Play Store.
    signingConfigs {
        getByName("debug") {
            storeFile = file("debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
    }

    buildTypes {
        debug {
            signingConfig = signingConfigs.getByName("debug")
        }
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("debug")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    buildFeatures {
        compose = true
    }
    composeOptions {
        kotlinCompilerExtensionVersion = "1.5.14"
    }
    packaging {
        resources.excludes += "/META-INF/{AL2.0,LGPL2.1}"
    }
}

dependencies {
    val composeBom = platform("androidx.compose:compose-bom:2024.06.00")
    implementation(composeBom)
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.activity:activity-compose:1.9.0")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-core")
    implementation("androidx.navigation:navigation-compose:2.7.7")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
    implementation("com.squareup.okhttp3:okhttp:4.12.0")

    // Meera Eyes (v2.1): CameraX is the ONLY new library (4 artifacts of the same library, one version).
    // 1.3.4 is used on purpose: it compiles against SDK 34 / AGP 8.5 (1.4.x asks for compileSdk 35).
    val cameraX = "1.3.4"
    implementation("androidx.camera:camera-core:$cameraX")
    implementation("androidx.camera:camera-camera2:$cameraX")
    implementation("androidx.camera:camera-lifecycle:$cameraX")
    implementation("androidx.camera:camera-view:$cameraX")

    // v2.4: avatar / home videos. ExoPlayer only (no media3-ui: the video is drawn on our own TextureView so it can cross-fade).
    // 1.3.1 compiles against SDK 34 (1.5.x asks for compileSdk 35).
    implementation("androidx.media3:media3-exoplayer:1.3.1")
}
