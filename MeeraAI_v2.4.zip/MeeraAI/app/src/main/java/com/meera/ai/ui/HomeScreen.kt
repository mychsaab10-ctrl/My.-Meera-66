package com.meera.ai.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBars
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import com.meera.ai.Meera
import com.meera.ai.go

/**
 * Home (v2.4): the sci-fi video fills the WHOLE screen (behind the status and navigation bars too), looped with a soft mix
 * so the restart is invisible. Four frosted-glass buttons float on top: Menu, Coding, Call, Chat.
 */
@Composable
fun HomeScreen(nav: NavHostController, onMenu: () -> Unit) {
    val hasKey = Meera.keys.has()

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        HomeScene()

        // soft dark gradients at the top and bottom keep the glass and the text readable on any frame of the video
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(
            0f to Color(0x6602040F), 0.16f to Color.Transparent, 0.70f to Color.Transparent, 1f to Color(0x9902040F)
        )))

        Column(
            Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.systemBars).padding(horizontal = 20.dp, vertical = 14.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // top bar: Menu button at the TOP-LEFT, status pill next to it
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                GlassButton(onMenu, Modifier.size(48.dp)) { Icon(Icons.Filled.Menu, "Menu", tint = Color.White, modifier = Modifier.size(24.dp)) }
                GlassPill(if (hasKey) "MEERA AI  •  ONLINE" else "MEERA AI  •  NO API KEY", if (hasKey) Color(0xFF34D399) else Pink)
            }

            Box(Modifier.weight(1f))

            if (!hasKey) {
                Text(
                    "Add your Gemini API key: Menu → Settings",
                    color = Color.White, fontSize = 12.sp, textAlign = TextAlign.Center,
                    modifier = Modifier.glass(RoundedCornerShape(50), 0.9f).clickable { nav.go("settings") }.padding(horizontal = 16.dp, vertical = 8.dp)
                )
                Box(Modifier.size(12.dp))
            }

            // glass dock: Coding | Call | Chat   (Menu is the glass button at the top-left)
            Row(
                Modifier.fillMaxWidth().glass(RoundedCornerShape(36.dp), 1.1f).padding(horizontal = 18.dp, vertical = 14.dp),
                horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically
            ) {
                DockItem("Coding", { nav.go("coding") }) {
                    Text("</>", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                }
                DockItem("Call", { nav.go("call") }, big = true, tint = Color(0xFF7C6CFF)) {
                    Icon(Icons.Filled.Call, "Start call", tint = Color.White, modifier = Modifier.size(32.dp))
                }
                DockItem("Chat", { nav.go("chat") }) { ChatGlyph() }
            }
        }
    }
}

@Composable
private fun DockItem(
    label: String,
    onClick: () -> Unit,
    big: Boolean = false,
    tint: Color? = null,
    icon: @Composable () -> Unit
) {
    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(6.dp)) {
        GlassButton(onClick, Modifier.size(if (big) 76.dp else 58.dp), CircleShape, tint = tint, strength = if (big) 1.2f else 1f) { icon() }
        GlassLabel(label)
    }
}

@Composable
private fun ChatGlyph() {
    Canvas(Modifier.size(24.dp)) {
        val w = size.width
        val h = size.height
        drawRoundRect(Color.White, Offset(0f, 0f), Size(w, h * 0.72f), CornerRadius(w * 0.22f), style = Stroke(2.2.dp.toPx()))
        val tail = Path().apply { moveTo(w * 0.22f, h * 0.7f); lineTo(w * 0.16f, h); lineTo(w * 0.52f, h * 0.72f); close() }
        drawPath(tail, Color.White)
        for (k in 0..2) drawCircle(Color.White, 1.8.dp.toPx(), Offset(w * (0.3f + 0.2f * k), h * 0.36f))
    }
}
