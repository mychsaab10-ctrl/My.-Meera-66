package com.meera.ai.automation

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.AlarmClock
import android.provider.CalendarContract
import android.provider.MediaStore
import android.provider.Settings
import android.app.SearchManager
import android.content.IntentFilter
import android.hardware.camera2.CameraAccessException
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.BatteryManager
import android.os.Build
import android.view.KeyEvent
import org.json.JSONObject
import java.time.LocalDateTime
import java.time.ZoneId

/**
 * Phone actions implemented ONLY with public Android intents.
 * A successful return value means "Android accepted the intent" - not that the task finished.
 * Calls only open the dialer (after the user says yes); messages are handled by Messaging.kt.
 */
object Actions {
    private val confirmActions = setOf("dial")

    fun needsConfirm(action: String) = action in confirmActions

    fun describe(args: JSONObject): String = when (args.optString("action")) {
        "dial" -> "Open the dialer with ${args.optString("number")}? You will press the Call button yourself. (yes / no)"
        else -> args.toString()
    }

    private fun launch(ctx: Context, i: Intent, what: String): String {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return try {
            ctx.startActivity(i)
            "Launched: $what. Android accepted the request (I cannot see what happens next)."
        } catch (e: ActivityNotFoundException) {
            "Failed: no app on this phone can handle \"$what\"."
        } catch (e: SecurityException) {
            "Failed: Android denied permission for \"$what\"."
        } catch (e: Exception) {
            "Failed: ${e.message}"
        }
    }

    fun run(ctx: Context, args: JSONObject): String {
        val q = args.optString("query").trim()
        return when (val a = args.optString("action")) {
            "open_app" -> openApp(ctx, q)
            "youtube_search" -> youtube(ctx, q)
            "play_music" -> playMusic(ctx, q)
            "open_url" -> {
                val url = if (q.startsWith("http://") || q.startsWith("https://")) q else "https://$q"
                launch(ctx, Intent(Intent.ACTION_VIEW, Uri.parse(url)), "open $url")
            }
            "web_search" -> launch(
                ctx, Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(q))),
                "web search for \"$q\""
            )
            "open_settings" -> launch(ctx, Intent(settingsAction(q)), "Settings ($q)")
            "open_camera" -> launch(ctx, Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA), "camera")
            "maps_search" -> launch(ctx, Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=" + Uri.encode(q))), "maps for \"$q\"")
            "set_alarm" -> {
                if (!args.has("hour")) return "Failed: no alarm time given."
                val i = Intent(AlarmClock.ACTION_SET_ALARM)
                    .putExtra(AlarmClock.EXTRA_HOUR, args.optInt("hour"))
                    .putExtra(AlarmClock.EXTRA_MINUTES, args.optInt("minute"))
                    .putExtra(AlarmClock.EXTRA_MESSAGE, args.optString("label", "Meera alarm"))
                    .putExtra(AlarmClock.EXTRA_SKIP_UI, false) // clock app shows it so you can confirm
                launch(ctx, i, "alarm %02d:%02d".format(args.optInt("hour"), args.optInt("minute")))
            }
            "set_timer" -> {
                val sec = args.optInt("seconds", 0)
                if (sec <= 0) return "Failed: no timer length given."
                val i = Intent(AlarmClock.ACTION_SET_TIMER)
                    .putExtra(AlarmClock.EXTRA_LENGTH, sec)
                    .putExtra(AlarmClock.EXTRA_MESSAGE, args.optString("label", "Meera timer"))
                    .putExtra(AlarmClock.EXTRA_SKIP_UI, false)
                launch(ctx, i, "timer for $sec seconds")
            }
            "calendar_event" -> calendar(ctx, args)
            "navigate" -> navigate(ctx, q, args.optString("mode"))
            "find_nearby" -> nearby(ctx, q)
            "torch_on" -> torch(ctx, true)
            "torch_off" -> torch(ctx, false)
            "volume_up", "volume_down", "volume_mute", "volume_set" -> volume(ctx, a, args.optInt("level", -1))
            "media_play_pause" -> media(ctx, KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE, "play / pause")
            "media_next" -> media(ctx, KeyEvent.KEYCODE_MEDIA_NEXT, "next track")
            "media_previous" -> media(ctx, KeyEvent.KEYCODE_MEDIA_PREVIOUS, "previous track")
            "media_stop" -> media(ctx, KeyEvent.KEYCODE_MEDIA_STOP, "stop")
            "phone_status" -> status(ctx)
            "send_email" -> launch(
                ctx,
                Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:" + Uri.encode(args.optString("to"))))
                    .putExtra(Intent.EXTRA_SUBJECT, args.optString("label"))
                    .putExtra(Intent.EXTRA_TEXT, args.optString("text")),
                "email draft (you press Send)"
            )
            "share_text" -> launch(
                ctx,
                Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, args.optString("text")), "Share"),
                "share sheet"
            )
            "open_play_store" -> launch(ctx, Intent(Intent.ACTION_VIEW, Uri.parse("market://search?q=" + Uri.encode(q))), "Play Store search for \"$q\"")
            "record_video" -> launch(ctx, Intent(MediaStore.ACTION_VIDEO_CAPTURE), "video recorder")
            "open_gallery" -> launch(ctx, Intent(Intent.ACTION_VIEW, MediaStore.Images.Media.EXTERNAL_CONTENT_URI), "gallery")
            "dial" -> launch(ctx, Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(args.optString("number")))), "dialer")
            else -> "Unsupported action: $a"
        }
    }

    @Suppress("DEPRECATION")
    private fun openApp(ctx: Context, name: String): String {
        if (name.isBlank()) return "Failed: no app name given."
        val pm = ctx.packageManager
        val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(main, 0)
        val n = name.lowercase()
        val hit = apps.firstOrNull { it.loadLabel(pm).toString().lowercase() == n }
            ?: apps.firstOrNull { it.loadLabel(pm).toString().lowercase().contains(n) }
            ?: return "Failed: I could not find an installed app called \"$name\"."
        val i = pm.getLaunchIntentForPackage(hit.activityInfo.packageName)
            ?: return "Failed: that app has no launch screen."
        return launch(ctx, i, "app ${hit.loadLabel(pm)}")
    }

    private fun youtube(ctx: Context, q: String): String {
        val yt = Intent(Intent.ACTION_SEARCH).setPackage("com.google.android.youtube").putExtra("query", q)
        yt.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return try {
            ctx.startActivity(yt)
            "Launched: YouTube search for \"$q\". Tap a result to play (Android does not allow auto-play)."
        } catch (e: Exception) {
            launch(ctx, Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(q))), "YouTube search in browser for \"$q\"")
        }
    }

    private fun playMusic(ctx: Context, q: String): String {
        val i = Intent(MediaStore.INTENT_ACTION_MEDIA_PLAY_FROM_SEARCH)
            .putExtra(MediaStore.EXTRA_MEDIA_FOCUS, "vnd.android.cursor.item/*")
            .putExtra(SearchManager.QUERY, q)
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return try {
            ctx.startActivity(i)
            "Launched: music search for \"$q\" in your music app (it decides whether to auto-play)."
        } catch (e: Exception) {
            youtube(ctx, "$q song")
        }
    }

    // ───────────── maps ─────────────

    private fun navigate(ctx: Context, dest: String, mode: String): String {
        if (dest.isBlank()) return "Failed: no destination given."
        val m = when (mode.lowercase()) { "walk", "walking", "w" -> "w"; "bike", "bicycle", "bicycling", "b" -> "b"; "two_wheeler", "motorcycle", "l" -> "l"; else -> "d" }
        val nav = Intent(Intent.ACTION_VIEW, Uri.parse("google.navigation:q=" + Uri.encode(dest) + "&mode=" + m)).setPackage("com.google.android.apps.maps")
        nav.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return try {
            ctx.startActivity(nav)
            "Launched: Google Maps navigation to \"$dest\". Maps now shows the route and gives turn-by-turn voice directions (I cannot see what happens next)."
        } catch (e: Exception) {
            val travel = when (m) { "w" -> "walking"; "b" -> "bicycling"; else -> "driving" }
            launch(ctx, Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/maps/dir/?api=1&destination=" + Uri.encode(dest) + "&travelmode=" + travel)), "directions to \"$dest\" in the browser")
        }
    }

    private fun nearby(ctx: Context, q: String): String {
        if (q.isBlank()) return "Failed: tell me what to look for (for example petrol pump, hospital, pharmacy)."
        // Only the search words are used. Google Maps itself finds where the user is (the app never gives it, or Gemini, a position).
        return launch(ctx, Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=" + Uri.encode(q))), "nearby \"$q\" on the map (Google Maps uses your own location)")
    }

    // ───────────── hardware / system ─────────────

    private fun torch(ctx: Context, on: Boolean): String {
        return try {
            val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val id = cm.cameraIdList.firstOrNull { cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true }
                ?: return "Failed: this phone has no flashlight."
            cm.setTorchMode(id, on)
            "Flashlight turned ${if (on) "ON" else "OFF"} (Android accepted the request)."
        } catch (e: CameraAccessException) {
            "Failed: the camera is busy (for example Meera Eyes or another app is using it)."
        } catch (e: Exception) {
            "Failed: ${e.message}"
        }
    }

    private fun volume(ctx: Context, action: String, level: Int): String {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        try {
            when (action) {
                "volume_up" -> am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI)
                "volume_down" -> am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI)
                "volume_mute" -> am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_MUTE, AudioManager.FLAG_SHOW_UI)
                else -> {
                    if (level !in 0..100) return "Failed: give a volume level from 0 to 100."
                    am.setStreamVolume(AudioManager.STREAM_MUSIC, (max * level / 100f).toInt().coerceIn(0, max), AudioManager.FLAG_SHOW_UI)
                }
            }
        } catch (e: SecurityException) {
            return "Failed: Android denied the volume change."
        }
        val now = am.getStreamVolume(AudioManager.STREAM_MUSIC)
        return "Media volume is now about ${now * 100 / max}%."
    }

    private fun media(ctx: Context, code: Int, what: String): String {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
        return "Sent media key: $what. It works only if a music/video app is active (I cannot see the result)."
    }

    private fun status(ctx: Context): String {
        val sb = StringBuilder("PHONE STATUS: ")
        try {
            val b = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            if (b != null) {
                val level = b.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
                val scale = b.getIntExtra(BatteryManager.EXTRA_SCALE, -1)
                val st = b.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
                val charging = st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL
                if (level >= 0 && scale > 0) sb.append("battery ${level * 100 / scale}%${if (charging) " (charging)" else ""}; ")
            }
        } catch (e: Exception) { }
        try {
            val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val caps = cm.getNetworkCapabilities(cm.activeNetwork)
            val net = when {
                caps == null -> "no internet"
                caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Wi-Fi"
                caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "mobile data"
                else -> "other network"
            }
            sb.append("network $net; ")
        } catch (e: Exception) { }
        try {
            val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
            sb.append("media volume ${am.getStreamVolume(AudioManager.STREAM_MUSIC) * 100 / max}%; ")
        } catch (e: Exception) { }
        sb.append("Android ${Build.VERSION.RELEASE}, ${Build.MANUFACTURER} ${Build.MODEL}.")
        return sb.toString()
    }

    private fun settingsAction(q: String): String {
        val s = q.lowercase()
        return when {
            ("wifi" in s || "wi-fi" in s || "internet" in s) && Build.VERSION.SDK_INT >= 29 -> Settings.Panel.ACTION_INTERNET_CONNECTIVITY
            "wifi" in s || "wi-fi" in s -> Settings.ACTION_WIFI_SETTINGS
            "bluetooth" in s -> Settings.ACTION_BLUETOOTH_SETTINGS
            "volume" in s && Build.VERSION.SDK_INT >= 29 -> Settings.Panel.ACTION_VOLUME
            "hotspot" in s || "tether" in s -> Settings.ACTION_WIRELESS_SETTINGS
            "nfc" in s -> Settings.ACTION_NFC_SETTINGS
            "data" in s -> Settings.ACTION_DATA_ROAMING_SETTINGS
            "disturb" in s || "dnd" in s || "silent" in s -> Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS
            "language" in s -> Settings.ACTION_LOCALE_SETTINGS
            "date" in s || "time" in s -> Settings.ACTION_DATE_SETTINGS
            "storage" in s -> Settings.ACTION_INTERNAL_STORAGE_SETTINGS
            "privacy" in s -> Settings.ACTION_PRIVACY_SETTINGS
            "security" in s -> Settings.ACTION_SECURITY_SETTINGS
            "cast" in s -> Settings.ACTION_CAST_SETTINGS
            "display" in s || "brightness" in s -> Settings.ACTION_DISPLAY_SETTINGS
            "sound" in s -> Settings.ACTION_SOUND_SETTINGS
            "battery" in s -> Settings.ACTION_BATTERY_SAVER_SETTINGS
            "location" in s || "gps" in s -> Settings.ACTION_LOCATION_SOURCE_SETTINGS
            "airplane" in s -> Settings.ACTION_AIRPLANE_MODE_SETTINGS
            "accessibility" in s -> Settings.ACTION_ACCESSIBILITY_SETTINGS
            "app" in s -> Settings.ACTION_APPLICATION_SETTINGS
            else -> Settings.ACTION_SETTINGS
        }
    }

    private fun calendar(ctx: Context, args: JSONObject): String {
        val iso = args.optString("start_iso")
        val begin = try {
            LocalDateTime.parse(iso).atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()
        } catch (e: Exception) {
            return "Failed: I need a valid start time (yyyy-MM-ddTHH:mm)."
        }
        val i = Intent(Intent.ACTION_INSERT, CalendarContract.Events.CONTENT_URI)
            .putExtra(CalendarContract.Events.TITLE, args.optString("label", "Meera event"))
            .putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME, begin)
            .putExtra(CalendarContract.EXTRA_EVENT_END_TIME, begin + 60 * 60 * 1000)
        return launch(ctx, i, "calendar event form (you press Save)")
    }
}
